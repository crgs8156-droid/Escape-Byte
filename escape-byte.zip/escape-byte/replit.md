# Escape Byte

Escape Byte is a real-time 1v1 arithmetic duel where friends race to answer five questions.

## Run & Operate

- `pnpm install` — install workspace dependencies
- `pnpm --filter @workspace/escape-byte run dev` — run the app in development
- `pnpm --filter @workspace/escape-byte run build` — build the Next.js app
- `pnpm --filter @workspace/escape-byte run start` — start the production build
- No environment secrets or database are required; the Replit workflow supplies `PORT`.

## Stack

- Next.js with React and Tailwind CSS
- Node.js with Express and Socket.IO
- pnpm workspaces and JavaScript
- No database, external APIs, third-party services, or authentication

## Where things live

- `artifacts/escape-byte/client/` — Next.js pages, styling, and browser Socket.IO client
- `artifacts/escape-byte/server/index.ts` — Express, Next.js request handler, and Socket.IO server
- `artifacts/escape-byte/server/game.ts` — in-memory rooms, questions, timers, scoring, and rematches
- `artifacts/escape-byte/.replit-artifact/artifact.toml` — app routes and development/production commands

## Architecture decisions

- Express and Next.js share one HTTP server and port; Socket.IO uses the `/socket.io` path.
- Room, question, and match state exists only in server memory and is cleared when the server restarts.
- Correct answers, round winners, deadlines, and scores are decided by the server.

## Product

- Players create or join a four-character room code, wait in a two-player lobby, race through five timed questions, and can start a rematch.

## Pointers

- The root workspace also contains shared starter artifacts; Escape Byte runs independently in `artifacts/escape-byte`.
