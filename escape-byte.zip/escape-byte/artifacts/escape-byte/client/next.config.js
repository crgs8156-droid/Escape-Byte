const replitDevDomain = process.env.REPLIT_DEV_DOMAIN?.trim();
const allowedDevOrigins = replitDevDomain
  ? [
      replitDevDomain,
      replitDevDomain.replace(/\.replit\.dev$/i, ".repl.co"),
      "127.0.0.1",
    ]
  : ["127.0.0.1"];

const nextConfig = {
  reactStrictMode: true,
  allowedDevOrigins,
};

export default nextConfig;