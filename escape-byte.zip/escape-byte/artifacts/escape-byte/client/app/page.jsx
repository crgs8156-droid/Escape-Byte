import EscapeByte from "./components/escape-byte";

export default function Page() {
  return <EscapeByte />;
}