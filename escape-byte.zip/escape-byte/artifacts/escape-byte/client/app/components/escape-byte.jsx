"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";

const socketPath = "/socket.io";
const QUESTION_CATEGORIES = [
  { value: "maths", label: "Maths" },
  { value: "code", label: "Code" },
  { value: "logic", label: "Logic" },
  { value: "mixed", label: "Mixed" },
];
const GAME_MODES = [
  { value: "classic", label: "Classic" },
  { value: "sprint", label: "Sprint" },
];
const SPRINT_DURATIONS = [1, 2, 5];
const QUESTION_CATEGORY_LABELS = Object.fromEntries(
  QUESTION_CATEGORIES.map(({ value, label }) => [value, label]),
);

function Mark() {
  return <div className="flex items-center gap-2.5" aria-label="Escape Byte">
    <span className="grid h-8 w-8 place-items-center rounded-[9px] bg-[#17211d] text-[#d4f05b]">
      <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" aria-hidden="true">
        <path d="M5 5.5h14v4H9v2h8v4H9v3H5V5.5Z" fill="currentColor"/>
        <path d="M17 15.5h2v3h-2z" fill="#f2794b"/>
      </svg>
    </span>
    <span className="display text-[17px] font-bold tracking-[-.07em]">escape byte<span className="text-[#f2794b]">.</span></span>
  </div>;
}

function TopBar({ connected }) {
  return <header className="flex h-[76px] items-center justify-between border-b border-[#d7d4c9] px-5 sm:px-9">
    <Mark />
    <div className="mono flex items-center gap-2 text-[10px] uppercase tracking-[.14em] text-[#718078]">
      <span className={`live-dot h-1.5 w-1.5 rounded-full ${connected ? "bg-[#819c3b]" : "bg-[#f2794b]"}`} />
      {connected ? "Ready to play" : "Connecting"}
    </div>
  </header>;
}

function Button({ children, onClick, disabled, secondary = false, type = "button" }) {
  return <button type={type} onClick={onClick} disabled={disabled}
    className={`group flex min-h-[54px] items-center justify-center gap-3 rounded-[13px] px-5 text-[14px] font-extrabold tracking-[-.02em] transition-all duration-200 active:translate-y-[1px] disabled:cursor-not-allowed disabled:opacity-45 ${
      secondary
        ? "border border-[#c9c8bb] bg-transparent text-[#17211d] hover:bg-[#e9e4d7]"
        : "bg-[#d4f05b] text-[#17211d] shadow-[0_3px_0_#a9c43f] hover:-translate-y-0.5 hover:bg-[#dcf66f] hover:shadow-[0_5px_0_#a9c43f]"
    }`}>
    {children}
  </button>;
}

function Arrow() {
  return <svg viewBox="0 0 20 20" className="h-4 w-4 transition-transform group-hover:translate-x-1" fill="none" aria-hidden="true">
    <path d="M3.5 10h12m-5-5 5 5-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}

export default function EscapeByte() {
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [nickname, setNickname] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("maths");
  const [selectedMode, setSelectedMode] = useState("classic");
  const [selectedDuration, setSelectedDuration] = useState(1);
  const [roomCodeInput, setRoomCodeInput] = useState("");
  const [room, setRoom] = useState(null);
  const [playerId, setPlayerId] = useState("");
  const [question, setQuestion] = useState(null);
  const [sprintQuestion, setSprintQuestion] = useState(null);
  const [round, setRound] = useState(null);
  const [answer, setAnswer] = useState("");
  const [sprintAnswer, setSprintAnswer] = useState("");
  const [answerFeedback, setAnswerFeedback] = useState("");
  const [sprintFeedback, setSprintFeedback] = useState(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [sprintNow, setSprintNow] = useState(Date.now());
  const [clockOffsetMs, setClockOffsetMs] = useState(0);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const answerRef = useRef(null);
  const sprintAnswerRef = useRef(null);
  const sprintFeedbackTimerRef = useRef(null);

  useEffect(() => {
    const socket = io({ path: socketPath, autoConnect: true, reconnection: true });
    socketRef.current = socket;
    const onConnect = () => { setConnected(true); setError(""); };
    const onDisconnect = () => setConnected(false);
    const onState = (state) => {
      setRoom(state);
      if (state.sprint?.serverNow) {
        setClockOffsetMs(state.sprint.serverNow - Date.now());
      }
      if (state.question) setQuestion({
        questionNumber: state.questionNumber,
        totalQuestions: state.totalQuestions,
        text: state.question.text,
          ...(state.question.options
            ? { options: state.question.options }
            : {}),
        deadlineAt: state.question.deadlineAt,
      });
      if (state.phase !== "playing") setRound(null);
      if (state.phase === "playing" && state.question) setAnswer("");
      if (state.phase === "lobby") {
        setSprintQuestion(null);
        setSprintFeedback(null);
      }
    };
    const onQuestion = (next) => {
      setQuestion(next);
      setSprintQuestion(null);
      setRound(null);
      setAnswer("");
      setAnswerFeedback("");
      window.setTimeout(() => answerRef.current?.focus(), 60);
    };
    const onSprintQuestion = (next) => {
      setSprintQuestion(next);
      setSprintAnswer("");
      window.setTimeout(() => sprintAnswerRef.current?.focus(), 60);
    };
    const onSprintAnswerResult = (result) => {
      setSprintFeedback(result);
      if (sprintFeedbackTimerRef.current) {
        window.clearTimeout(sprintFeedbackTimerRef.current);
      }
      sprintFeedbackTimerRef.current = window.setTimeout(
        () => setSprintFeedback(null),
        Math.min(450, result.feedbackMs ?? 350),
      );
    };
    const onRound = (result) => setRound(result);
    const onAnswerFeedback = ({ correct }) => {
      setAnswerFeedback(correct ? "" : "Not quite — try again.");
    };
    const onRoomError = ({ message }) => { setError(message); setPending(false); };
    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    socket.on("room:state", onState);
    socket.on("game:question", onQuestion);
    socket.on("game:round-result", onRound);
    socket.on("game:answer-feedback", onAnswerFeedback);
    socket.on("sprint:question", onSprintQuestion);
    socket.on("sprint:answer-result", onSprintAnswerResult);
    socket.on("room:error", onRoomError);
    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      socket.off("room:state", onState);
      socket.off("game:question", onQuestion);
      socket.off("game:round-result", onRound);
      socket.off("game:answer-feedback", onAnswerFeedback);
      socket.off("sprint:question", onSprintQuestion);
      socket.off("sprint:answer-result", onSprintAnswerResult);
      socket.off("room:error", onRoomError);
      if (sprintFeedbackTimerRef.current) {
        window.clearTimeout(sprintFeedbackTimerRef.current);
      }
      socket.disconnect();
      socketRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!question?.deadlineAt || room?.phase !== "playing") return;
    const update = () => setSecondsLeft(Math.max(0, (question.deadlineAt - Date.now()) / 1000));
    update();
    const timer = window.setInterval(update, 80);
    return () => window.clearInterval(timer);
  }, [question, room?.phase]);

  useEffect(() => {
    if (
      room?.mode !== "sprint" ||
      !["countdown", "playing"].includes(room.phase) ||
      !room.sprint
    ) {
      return;
    }
    const update = () => setSprintNow(Date.now());
    update();
    const timer = window.setInterval(update, 80);
    return () => window.clearInterval(timer);
  }, [
    room?.mode,
    room?.phase,
    room?.sprint?.countdownEndsAt,
    room?.sprint?.endsAt,
    clockOffsetMs,
  ]);

  const createRoom = useCallback((event) => {
    event.preventDefault();
    if (!nickname.trim() || !socketRef.current?.connected) return;
    setPending(true); setError("");
    const roomOptions = {
      nickname: nickname.trim(),
      category: selectedCategory,
      mode: selectedMode,
      ...(selectedMode === "sprint"
        ? { durationMinutes: selectedDuration }
        : {}),
    };
    socketRef.current.emit("room:create", roomOptions, (ack) => {
      setPending(false);
      if (ack.ok === false) { setError(ack.error); return; }
      setPlayerId(ack.playerId);
    });
  }, [nickname, selectedCategory, selectedMode, selectedDuration]);

  const joinRoom = useCallback((event) => {
    event.preventDefault();
    if (!nickname.trim() || !roomCodeInput.trim() || !socketRef.current?.connected) return;
    setPending(true); setError("");
    socketRef.current.emit("room:join", { nickname: nickname.trim(), roomCode: roomCodeInput.trim().toUpperCase() }, (ack) => {
      setPending(false);
      if (ack.ok === false) { setError(ack.error); return; }
      setPlayerId(ack.playerId);
    });
  }, [nickname, roomCodeInput]);

  const submitAnswer = (event) => {
    event.preventDefault();
    if (!answer.trim() || !socketRef.current?.connected || round) return;
    socketRef.current.emit("game:answer", { answer: answer.trim() });
    setAnswer("");
  };

  const submitChoice = (optionIndex) => {
    if (!socketRef.current?.connected || !question?.options || round) return;
    socketRef.current.emit("game:answer", { answer: String(optionIndex) });
  };

  const submitSprintAnswer = (event) => {
    event.preventDefault();
    if (!sprintAnswer.trim() || !socketRef.current?.connected || !sprintQuestion) return;
    socketRef.current.emit("sprint:answer", {
      questionNumber: sprintQuestion.questionNumber,
      answer: sprintAnswer.trim(),
    });
    setSprintAnswer("");
  };

  const submitSprintChoice = (optionIndex) => {
    if (!socketRef.current?.connected || !sprintQuestion) return;
    socketRef.current.emit("sprint:answer", {
      questionNumber: sprintQuestion.questionNumber,
      answer: String(optionIndex),
    });
  };

  const copyCode = async () => {
    if (!room?.roomCode) return;
    try {
      await navigator.clipboard.writeText(room.roomCode);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch { setError("Could not copy the room code. Select it to copy."); }
  };

  const startGame = () => {
    setError("");
    socketRef.current?.emit("room:start");
  };

  const playAgain = () => {
    setError("");
    setQuestion(null);
    setSprintQuestion(null);
    setSprintAnswer("");
    setSprintFeedback(null);
    setRound(null);
    socketRef.current?.emit("room:play-again");
  };

  const opponent = room?.players.find((player) => player.id !== playerId);
  const isHome = !room;
  const isLobby = room?.phase === "lobby";
  const isCountdown = room?.phase === "countdown";
  const isPlaying = room?.phase === "playing";
  const isFinished = room?.phase === "finished";
  const sprintClockNow = sprintNow + clockOffsetMs;
  const sprintCountdown = room?.sprint
    ? Math.max(1, Math.ceil((room.sprint.countdownEndsAt - sprintClockNow) / 1000))
    : 3;
  const sprintSecondsLeft = room?.sprint
    ? Math.max(0, (room.sprint.endsAt - sprintClockNow) / 1000)
    : 0;
  const sprintResultPlayers = room?.sprintResults?.players ?? [];
  const sprintWinner = room?.players.find((player) => player.id === room.winnerId);

  return <main className="paper-grain min-h-[100dvh]">
    <TopBar connected={connected} />
    {isHome && <section className="mx-auto grid min-h-[calc(100dvh-76px)] max-w-[1120px] items-center gap-10 px-5 py-12 md:grid-cols-[1.1fr_.9fr] md:px-9 md:py-16">
      <div className="fade-up relative pb-5">
        <div className="mono mb-6 inline-flex items-center gap-2 rounded-full border border-[#c9c8bb] px-3 py-1.5 text-[10px] uppercase tracking-[.14em] text-[#718078]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#f2794b]" /> 1v1 · 5 rounds · no pressure
        </div>
        <h1 className="display max-w-[630px] text-[clamp(3.6rem,8vw,7.2rem)] font-bold leading-[.89] tracking-[-.085em]">
          Quick wits.<br/><span className="relative z-0 inline-block">Quicker</span><br/>
          <span className="relative inline-block">numbers<span className="absolute -bottom-1 left-0 -z-10 h-[22%] w-full -rotate-1 bg-[#d4f05b]" /></span>
          <span className="text-[#f2794b]">.</span>
        </h1>
        <p className="mt-7 max-w-[390px] text-[15px] leading-7 text-[#64726b]">
          A tiny head-to-head math sprint. Grab a friend, open a room, and see who gets there first.
        </p>
        <div className="mt-10 flex items-center gap-3">
          <div className="flex -space-x-2">
            <span className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#f3f0e7] bg-[#b8dbc8] text-[10px] font-extrabold">12</span>
            <span className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#f3f0e7] bg-[#f3b89c] text-[10px] font-extrabold">+</span>
          </div>
          <span className="text-[11px] font-semibold text-[#718078]">Fast rounds. Friendly bragging rights.</span>
        </div>
      </div>

      <div className="fade-up-delay relative mx-auto w-full max-w-[440px]">
        <div className="absolute -right-2 top-4 hidden rotate-6 rounded-[9px] bg-[#f2794b] px-3 py-2 text-[10px] font-extrabold uppercase tracking-[.12em] text-[#17211d] shadow-[3px_3px_0_#17211d] sm:block">Your brain, on the clock</div>
        <div className="relative overflow-hidden rounded-[24px] border border-[#d7d4c9] bg-[#ebe8de] p-5 shadow-[0_14px_40px_rgba(23,33,29,.08)] sm:p-7">
          <div className="mono flex items-center justify-between text-[10px] uppercase tracking-[.15em] text-[#718078]">
            <span>Sample round</span><span>01 / 05</span>
          </div>
          <div className="mt-6 flex items-center justify-between rounded-[17px] bg-[#f7f5ef] px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-[#d4f05b] text-[11px] font-extrabold">Y</span>
              <div><div className="text-[12px] font-extrabold">You</div><div className="mono text-[10px] text-[#718078]">score · 2</div></div>
            </div>
            <span className="mono rounded-md bg-[#e9e4d7] px-2 py-1 text-[10px] uppercase tracking-wider">vs</span>
            <div className="flex items-center gap-3 text-right">
              <div><div className="text-[12px] font-extrabold">Friend</div><div className="mono text-[10px] text-[#718078]">score · 1</div></div>
              <span className="grid h-9 w-9 place-items-center rounded-full bg-[#f3b89c] text-[11px] font-extrabold">F</span>
            </div>
          </div>
          <div className="mt-4 rounded-[18px] bg-[#17211d] p-6 text-[#f3f0e7] sm:p-8">
            <div className="mono flex items-center justify-between text-[10px] uppercase tracking-[.15em] text-[#acb7ae]">
              <span>Beat the clock</span><span className="text-[#d4f05b]">00:08</span>
            </div>
            <div className="display mt-8 text-center text-[clamp(2.3rem,7vw,3.5rem)] font-bold tracking-[-.07em]">17 × 6 <span className="text-[#d4f05b]">= ?</span></div>
            <div className="mx-auto mt-6 flex max-w-[230px] items-center justify-between border-b border-[#536057] pb-3">
              <span className="mono text-[13px] tracking-[.25em] text-[#acb7ae]">TYPE ANSWER</span>
              <span className="grid h-7 w-7 place-items-center rounded-md bg-[#d4f05b] text-[#17211d]">
                <Arrow/>
              </span>
            </div>
          </div>
          <div className="mt-5 flex items-center justify-between text-[10px] font-bold uppercase tracking-[.14em] text-[#718078]">
            <span className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#819c3b]"/> Room is private</span>
            <span>First correct wins the point</span>
          </div>
        </div>
      </div>

      <div className="md:col-span-2">
        <div className="grid gap-7 border-t border-[#d7d4c9] pt-8 md:grid-cols-[1fr_1fr] md:gap-12">
          <form onSubmit={createRoom} className="space-y-4">
            <div className="flex items-baseline justify-between">
              <h2 className="display text-[21px] font-bold tracking-[-.05em]">Start a new duel</h2>
              <span className="mono text-[9px] uppercase tracking-[.15em] text-[#718078]">Host a room</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="sr-only" htmlFor="nickname-create">Your nickname</label>
              <input id="nickname-create" value={nickname} onChange={(e) => setNickname(e.target.value)} maxLength={18} placeholder="Your nickname"
                className="h-[54px] min-w-0 rounded-[13px] border border-[#d7d4c9] bg-[#f8f6f0] px-4 text-[14px] font-semibold placeholder:text-[#9ba49b] focus:border-[#889b55] focus:outline-none sm:col-span-2" />
              <label className="sr-only" htmlFor="question-category">Question category</label>
              <select id="question-category" value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}
                className="mono h-[54px] w-full rounded-[13px] border border-[#d7d4c9] bg-[#f8f6f0] px-3 text-[12px] font-semibold text-[#17211d] focus:border-[#889b55] focus:outline-none">
                {QUESTION_CATEGORIES.map(({ value, label }) => <option key={value} value={value}>{label}</option>)}
              </select>
              <label className="sr-only" htmlFor="game-mode">Game mode</label>
              <select id="game-mode" value={selectedMode} onChange={(e) => setSelectedMode(e.target.value)}
                className="mono h-[54px] w-full rounded-[13px] border border-[#d7d4c9] bg-[#f8f6f0] px-3 text-[12px] font-semibold text-[#17211d] focus:border-[#889b55] focus:outline-none">
                {GAME_MODES.map(({ value, label }) => <option key={value} value={value}>{label}</option>)}
              </select>
              {selectedMode === "sprint" ? <>
                <label className="sr-only" htmlFor="sprint-duration">Sprint duration</label>
                <select id="sprint-duration" value={selectedDuration} onChange={(e) => setSelectedDuration(Number(e.target.value))}
                  className="mono h-[54px] w-full rounded-[13px] border border-[#d7d4c9] bg-[#f8f6f0] px-3 text-[12px] font-semibold text-[#17211d] focus:border-[#889b55] focus:outline-none">
                  {SPRINT_DURATIONS.map((minutes) => <option key={minutes} value={minutes}>{minutes} {minutes === 1 ? "minute" : "minutes"}</option>)}
                </select>
              </> : <div className="mono flex h-[54px] items-center rounded-[13px] border border-[#d7d4c9] px-3 text-[11px] uppercase tracking-[.12em] text-[#718078]">5 rounds</div>}
              <div className="flex justify-end sm:col-span-2">
                <Button type="submit" disabled={pending || !connected || !nickname.trim()}>
                  {pending ? "Opening room…" : "Create room"} <Arrow />
                </Button>
              </div>
            </div>
          </form>
          <form onSubmit={joinRoom} className="space-y-4">
            <div className="flex items-baseline justify-between">
              <h2 className="display text-[21px] font-bold tracking-[-.05em]">Got an invite?</h2>
              <span className="mono text-[9px] uppercase tracking-[.15em] text-[#718078]">Join a room</span>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <label className="sr-only" htmlFor="nickname-join">Your nickname</label>
              <input id="nickname-join" value={nickname} onChange={(e) => setNickname(e.target.value)} maxLength={18} placeholder="Your nickname"
                className="h-[54px] min-w-0 flex-1 rounded-[13px] border border-[#d7d4c9] bg-[#f8f6f0] px-4 text-[14px] font-semibold placeholder:text-[#9ba49b] focus:border-[#889b55] focus:outline-none" />
              <label className="sr-only" htmlFor="room-code">Room code</label>
              <input id="room-code" value={roomCodeInput} onChange={(e) => setRoomCodeInput(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))} maxLength={4} placeholder="ROOM CODE"
                className="mono h-[54px] w-full rounded-[13px] border border-[#d7d4c9] bg-[#f8f6f0] px-4 text-[13px] font-medium uppercase tracking-[.14em] placeholder:text-[#9ba49b] focus:border-[#889b55] focus:outline-none sm:w-[145px]" />
              <Button type="submit" disabled={pending || !connected || !nickname.trim() || !roomCodeInput.trim()} secondary>
                Join <Arrow />
              </Button>
            </div>
          </form>
        </div>
        {error && <p role="alert" className="mt-4 rounded-lg bg-[#f9ded3] px-4 py-3 text-[13px] font-semibold text-[#8a3d26]">{error}</p>}
        {!connected && <p className="mt-3 text-[12px] text-[#8a6a58]">Reconnecting to the game server…</p>}
      </div>
    </section>}

    {isLobby && room && <section className="mx-auto flex min-h-[calc(100dvh-76px)] max-w-[860px] flex-col justify-center px-5 py-12 sm:px-9">
      <div className="fade-up">
        <div className="mono mb-4 text-[10px] uppercase tracking-[.17em] text-[#718078]">
          Room {room.roomCode} · {room.mode === "sprint"
            ? `Sprint · ${room.durationMinutes} ${room.durationMinutes === 1 ? "minute" : "minutes"}`
            : "Classic · 5 rounds"} · {QUESTION_CATEGORY_LABELS[room.category] ?? "Maths"}
        </div>
        <h1 className="display text-[clamp(3rem,8vw,5.6rem)] font-bold leading-[.92] tracking-[-.08em]">
          Room’s open<span className="text-[#f2794b]">.</span><br/>
          <span className="text-[#718078]">{room.players.length < 2 ? "Waiting on your friend" : "Ready when you are"}</span>
        </h1>
      </div>
      <div className="fade-up-delay mt-10 grid gap-6 md:grid-cols-[1fr_280px]">
        <div className="rounded-[22px] border border-[#d7d4c9] bg-[#ebe8de] p-5 sm:p-7">
          <div className="mono flex items-center justify-between text-[10px] uppercase tracking-[.15em] text-[#718078]">
            <span>Players</span><span>{room.players.length} / 2</span>
          </div>
          <div className="mt-5 space-y-3">
            {room.players.map((player) => <div key={player.id} className="flex items-center gap-3 rounded-[15px] bg-[#f7f5ef] px-4 py-4">
              <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full text-[12px] font-extrabold ${player.id === room.hostId ? "bg-[#d4f05b]" : "bg-[#f3b89c]"}`}>{player.nickname.slice(0, 1).toUpperCase()}</span>
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-extrabold">{player.nickname}{player.id === playerId ? <span className="ml-2 text-[11px] font-semibold text-[#718078]">(you)</span> : null}</div>
                <div className="mono mt-1 text-[9px] uppercase tracking-[.13em] text-[#718078]">{player.id === room.hostId ? "Room host" : "Challenger"}</div>
              </div>
              <span className="mono text-[10px] text-[#718078]">0 PTS</span>
            </div>)}
            {room.players.length < 2 && <div className="flex items-center gap-3 rounded-[15px] border border-dashed border-[#c6c8ba] px-4 py-4">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-[#e4e1d7] text-[#718078]">
                <svg viewBox="0 0 20 20" className="h-4 w-4" fill="none" aria-hidden="true"><path d="M10 4v12M4 10h12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
              </span>
              <div><div className="text-[13px] font-bold text-[#718078]">Your friend</div><div className="mono mt-1 text-[9px] uppercase tracking-[.13em] text-[#9ba49b]">Joining soon…</div></div>
              <span className="live-dot ml-auto h-2 w-2 rounded-full bg-[#f2794b]"/>
            </div>}
          </div>
          <div className="mt-6 border-t border-[#d7d4c9] pt-5">
            <div className="mono text-[9px] uppercase tracking-[.15em] text-[#718078]">Send your friend this code</div>
            <button onClick={copyCode} className="mt-2 flex w-full items-center justify-between rounded-xl bg-[#17211d] px-4 py-3.5 text-left text-[#f3f0e7] transition-colors hover:bg-[#29362f]">
              <span className="mono text-[23px] font-medium tracking-[.2em]">{room.roomCode}</span>
              <span className="mono text-[9px] uppercase tracking-[.14em] text-[#d4f05b]">{copied ? "Copied" : "Copy code"}</span>
            </button>
          </div>
        </div>
        <aside className="flex flex-col justify-between rounded-[22px] bg-[#17211d] p-6 text-[#f3f0e7]">
          <div>
            <div className="mono text-[9px] uppercase tracking-[.16em] text-[#acb7ae]">How it goes</div>
            <div className="mt-5 space-y-4">
              {(room.mode === "sprint"
                ? [["01", "3-2-1 countdown, then race"], ["02", "Correct +1 · wrong −1"], ["03", "Fewer wrong breaks a score tie"]]
                : [["01", "Five quick questions"], ["02", "First correct answer scores"], ["03", "Most points takes it"]]
              ).map(([n, label]) =>
                <div key={n} className="flex gap-3"><span className="mono text-[10px] text-[#d4f05b]">{n}</span><span className="text-[12px] font-semibold leading-5 text-[#d3d9d1]">{label}</span></div>)}
            </div>
          </div>
          <div className="mt-9">
            {room.hostId === playerId ? <Button onClick={startGame} disabled={room.players.length < 2 || !connected}>{room.mode === "sprint" ? "Start Sprint" : "Start the duel"} <Arrow /></Button> :
              <div className="rounded-xl border border-[#39483f] px-4 py-4 text-center">
                <span className="live-dot mx-auto mb-2 block h-2 w-2 rounded-full bg-[#d4f05b]"/>
                <p className="text-[12px] font-bold">Waiting for the host</p>
                <p className="mt-1 text-[10px] text-[#acb7ae]">They’ll start the first round.</p>
              </div>}
            {error && <p role="alert" className="mt-4 text-[12px] font-semibold text-[#ffc0a3]">{error}</p>}
          </div>
        </aside>
      </div>
    </section>}

    {isCountdown && room?.mode === "sprint" && <section className="mx-auto flex min-h-[calc(100dvh-76px)] max-w-[860px] flex-col justify-center px-5 py-12 text-center sm:px-9">
      <div className="fade-up">
        <div className="mono text-[10px] uppercase tracking-[.18em] text-[#718078]">Sprint begins together · {QUESTION_CATEGORY_LABELS[room.category]}</div>
        <div aria-live="assertive" className="display mt-5 text-[clamp(8rem,28vw,15rem)] font-bold leading-[.8] tracking-[-.1em] text-[#17211d]">
          {sprintCountdown}
        </div>
        <p className="mt-8 text-[14px] font-semibold text-[#718078]">Get ready. Your first question arrives at zero.</p>
      </div>
      <div className="fade-up-delay mx-auto mt-10 grid w-full max-w-[560px] gap-3 sm:grid-cols-2">
        {room.players.map((player) => <div key={player.id} className="rounded-[16px] bg-[#ebe8de] px-5 py-4">
          <div className="text-[13px] font-extrabold">{player.nickname}{player.id === playerId ? " · you" : ""}</div>
          <div className="mono mt-2 text-[10px] uppercase tracking-[.14em] text-[#718078]">Ready to sprint</div>
        </div>)}
      </div>
    </section>}

    {isPlaying && room?.mode === "sprint" && <section className="mx-auto min-h-[calc(100dvh-76px)] max-w-[980px] px-5 py-7 sm:px-9 sm:py-10">
      <div className="fade-up flex items-center justify-between">
        <div>
          <div className="mono text-[10px] uppercase tracking-[.15em] text-[#718078]">Sprint · {QUESTION_CATEGORY_LABELS[room.category]}</div>
          <h1 className="display mt-1 text-[28px] font-bold tracking-[-.06em]">Keep moving<span className="text-[#f2794b]">.</span></h1>
        </div>
        <div className={`mono rounded-full border border-[#d7d4c9] px-3 py-2 text-[12px] tabular-nums ${sprintSecondsLeft < 10 ? "text-[#f2794b]" : "text-[#718078]"}`}>
          {Math.floor(sprintSecondsLeft / 60).toString().padStart(2, "0")}:{Math.floor(sprintSecondsLeft % 60).toString().padStart(2, "0")}
        </div>
      </div>
      <div className="fade-up-delay mt-7 grid gap-5 md:grid-cols-[1fr_250px]">
        <div className="overflow-hidden rounded-[23px] bg-[#17211d] text-[#f3f0e7]">
          <div className="flex items-center justify-between px-5 pt-5 sm:px-8 sm:pt-7">
            <span className="mono text-[10px] uppercase tracking-[.15em] text-[#acb7ae]">
              Question {sprintQuestion?.questionNumber ?? 0}
            </span>
            <span className="mono text-[10px] uppercase tracking-[.13em] text-[#acb7ae]">
              {sprintQuestion?.category ? `${QUESTION_CATEGORY_LABELS[sprintQuestion.category]} round` : "Your next question"}
            </span>
          </div>
          <div className="mx-5 mt-3 h-[3px] overflow-hidden rounded-full bg-[#39483f] sm:mx-8">
            <div className="h-full rounded-full bg-[#d4f05b] transition-[width] duration-100" style={{ width: `${Math.max(0, Math.min(100, (sprintSecondsLeft / (room.durationMinutes * 60)) * 100))}%` }}/>
          </div>
          <div className="relative flex min-h-[320px] flex-col items-center justify-center px-5 py-10 text-center sm:min-h-[370px]">
            {sprintQuestion ? <>
              <div aria-live="polite" className={`whitespace-pre-wrap ${
                sprintQuestion.options
                  ? "mono text-[clamp(1rem,3.4vw,1.75rem)] leading-relaxed tracking-normal"
                  : "display text-[clamp(3.1rem,10vw,6.4rem)] font-bold leading-none tracking-[-.09em]"
              }`}>
                {sprintQuestion.text}
                {!sprintQuestion.options && <span className="text-[#d4f05b]"> = ?</span>}
              </div>
              {sprintQuestion.options ? <div className="mt-8 grid w-full max-w-[520px] grid-cols-1 gap-2 sm:grid-cols-2">
                {sprintQuestion.options.map((option, index) => <button
                  key={`${index}-${option}`}
                  type="button"
                  onClick={() => submitSprintChoice(index)}
                  disabled={!connected}
                  className="flex min-h-[54px] items-center gap-3 rounded-[13px] border border-[#536057] bg-[#29362f] px-4 py-3 text-left text-[13px] font-semibold text-[#f3f0e7] transition-colors hover:border-[#d4f05b] hover:bg-[#344239] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <span className="mono grid h-7 w-7 shrink-0 place-items-center rounded-md bg-[#d4f05b] text-[10px] font-bold text-[#17211d]">
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="min-w-0 break-words">{option}</span>
                </button>)}
              </div> : <form onSubmit={submitSprintAnswer} className="mt-9 flex w-full max-w-[330px] items-center gap-2 border-b border-[#536057] pb-2">
                <label className="sr-only" htmlFor="sprint-answer-input">Your answer</label>
                <input ref={sprintAnswerRef} id="sprint-answer-input" inputMode="numeric" autoComplete="off" value={sprintAnswer} onChange={(e) => setSprintAnswer(e.target.value)} placeholder="Type your answer"
                  className="mono min-w-0 flex-1 bg-transparent py-2 text-[15px] text-[#f3f0e7] placeholder:text-[#718078] focus:outline-none" />
                <button type="submit" disabled={!sprintAnswer.trim() || !connected} aria-label="Submit Sprint answer" className="grid h-10 w-10 shrink-0 place-items-center rounded-[11px] bg-[#d4f05b] text-[#17211d] transition-transform hover:scale-105 disabled:opacity-40">
                  <Arrow/>
                </button>
              </form>}
              {sprintFeedback && <div role="status" className={`absolute bottom-4 rounded-full px-4 py-2 text-[11px] font-extrabold uppercase tracking-[.12em] ${
                sprintFeedback.correct ? "bg-[#d4f05b] text-[#17211d]" : "bg-[#f3b89c] text-[#17211d]"
              }`}>
                {sprintFeedback.correct ? "+1 · Correct" : "Wrong · keep going"}
              </div>}
            </> : <div className="w-full max-w-[360px]">
              <div className="mx-auto mb-5 h-3 w-28 animate-pulse rounded bg-[#39483f]"/>
              <div className="mx-auto h-16 w-64 rounded bg-[#29362f]"/>
              <p className="mt-6 text-[12px] text-[#acb7ae]">Getting your next question…</p>
            </div>}
          </div>
        </div>
        <aside className="rounded-[22px] border border-[#d7d4c9] bg-[#ebe8de] p-5 sm:p-6">
          <div className="mono flex items-center justify-between text-[10px] uppercase tracking-[.15em] text-[#718078]"><span>Live scores</span><span>Now</span></div>
          <div className="mt-5 space-y-3">
            {room.players.map((player) => <div key={player.id} className={`rounded-[15px] px-4 py-4 ${player.id === playerId ? "bg-[#d4f05b]" : "bg-[#f7f5ef]"}`}>
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-[12px] font-extrabold">{player.nickname}{player.id === playerId ? " · you" : ""}</span>
                {player.id === room.hostId && <span className="mono text-[8px] uppercase tracking-wider opacity-55">host</span>}
              </div>
              <div className="display mt-2 text-[34px] font-bold leading-none tracking-[-.07em]">{player.score}<span className="mono ml-2 text-[9px] font-normal uppercase tracking-[.14em]">pts</span></div>
              <div className="mono mt-3 text-[9px] uppercase tracking-[.11em] opacity-70">{player.questionsAnswered ?? 0} answered</div>
            </div>)}
          </div>
          <div className="mt-5 border-t border-[#d7d4c9] pt-4 text-[11px] leading-5 text-[#718078]">
            Correct adds a point. Wrong costs one, but your score never drops below zero.
          </div>
          {error && <p role="alert" className="mt-3 text-[11px] font-semibold text-[#a44e32]">{error}</p>}
        </aside>
      </div>
    </section>}

    {isPlaying && room?.mode !== "sprint" && room && <section className="mx-auto min-h-[calc(100dvh-76px)] max-w-[980px] px-5 py-7 sm:px-9 sm:py-10">
      <div className="fade-up flex items-center justify-between">
        <div>
          <div className="mono text-[10px] uppercase tracking-[.15em] text-[#718078]">Live duel</div>
          <h1 className="display mt-1 text-[28px] font-bold tracking-[-.06em]">Stay sharp<span className="text-[#f2794b]">.</span></h1>
        </div>
        <div className="mono rounded-full border border-[#d7d4c9] px-3 py-2 text-[10px] uppercase tracking-[.12em] text-[#718078]">
          Round {question?.questionNumber ?? room.questionNumber} <span className="mx-1 text-[#c1c3b6]">/</span> 5
        </div>
      </div>
      <div className="fade-up-delay mt-7 grid gap-5 md:grid-cols-[1fr_250px]">
        <div className="overflow-hidden rounded-[23px] bg-[#17211d] text-[#f3f0e7]">
          <div className="flex items-center justify-between px-5 pt-5 sm:px-8 sm:pt-7">
            <span className="mono text-[10px] uppercase tracking-[.15em] text-[#acb7ae]">Question {question?.questionNumber ?? room.questionNumber} of 5</span>
            <span className={`mono text-[12px] tabular-nums ${secondsLeft < 3 ? "text-[#f2794b]" : "text-[#d4f05b]"}`}>{secondsLeft.toFixed(1).padStart(4, "0")}s</span>
          </div>
          <div className="mx-5 mt-3 h-[3px] overflow-hidden rounded-full bg-[#39483f] sm:mx-8">
            <div className="h-full rounded-full bg-[#d4f05b] transition-[width] duration-100" style={{ width: `${Math.max(0, Math.min(100, secondsLeft * 10))}%` }}/>
          </div>
          <div className="flex min-h-[300px] flex-col items-center justify-center px-5 py-10 text-center sm:min-h-[350px]">
            {question ? <>
              <div className="mono mb-6 text-[9px] uppercase tracking-[.2em] text-[#acb7ae]">First correct answer wins the point</div>
              <div aria-live="polite" className={`whitespace-pre-wrap ${
                question.options
                  ? "mono text-[clamp(1rem,3.4vw,1.75rem)] leading-relaxed tracking-normal"
                  : "display text-[clamp(3.1rem,10vw,6.4rem)] font-bold leading-none tracking-[-.09em]"
              }`}>
                {question.text}
                {!question.options && <span className="text-[#d4f05b]"> = ?</span>}
              </div>
              {round ? <div className="mt-8 rounded-xl bg-[#29362f] px-5 py-3 text-[13px] font-bold text-[#d4f05b]">
                {round.winnerId === null ? "No point this round" : round.winnerId === playerId ? "Point to you. Nice." : `${opponent?.nickname ?? "Your friend"} got there first.`}
              </div> : question.options ? <div className="mt-8 grid w-full max-w-[520px] grid-cols-1 gap-2 sm:grid-cols-2">
                {question.options.map((option, index) => <button
                  key={`${index}-${option}`}
                  type="button"
                  onClick={() => submitChoice(index)}
                  disabled={!connected || Boolean(round)}
                  className="flex min-h-[54px] items-center gap-3 rounded-[13px] border border-[#536057] bg-[#29362f] px-4 py-3 text-left text-[13px] font-semibold text-[#f3f0e7] transition-colors hover:border-[#d4f05b] hover:bg-[#344239] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <span className="mono grid h-7 w-7 shrink-0 place-items-center rounded-md bg-[#d4f05b] text-[10px] font-bold text-[#17211d]">
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="min-w-0 break-words">{option}</span>
                </button>)}
              </div> : <form onSubmit={submitAnswer} className="mt-9 flex w-full max-w-[330px] items-center gap-2 border-b border-[#536057] pb-2">
                <label className="sr-only" htmlFor="answer-input">Your answer</label>
                <input ref={answerRef} id="answer-input" inputMode="numeric" autoComplete="off" value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Type your answer"
                  className="mono min-w-0 flex-1 bg-transparent py-2 text-[15px] text-[#f3f0e7] placeholder:text-[#718078] focus:outline-none" />
                <button type="submit" disabled={!answer.trim()} aria-label="Submit answer" className="grid h-10 w-10 shrink-0 place-items-center rounded-[11px] bg-[#d4f05b] text-[#17211d] transition-transform hover:scale-105 disabled:opacity-40">
                  <Arrow/>
                </button>
              </form>}
              {answerFeedback && <p role="status" className="mt-3 text-[12px] font-semibold text-[#f3b89c]">{answerFeedback}</p>}
            </> : <div className="w-full max-w-[360px]">
              <div className="mx-auto mb-5 h-3 w-28 animate-pulse rounded bg-[#39483f]"/>
              <div className="mx-auto h-16 w-64 rounded bg-[#29362f]"/>
              <p className="mt-6 text-[12px] text-[#acb7ae]">Getting the next one ready…</p>
            </div>}
          </div>
        </div>
        <aside className="rounded-[22px] border border-[#d7d4c9] bg-[#ebe8de] p-5 sm:p-6">
          <div className="mono flex items-center justify-between text-[10px] uppercase tracking-[.15em] text-[#718078]"><span>Scoreboard</span><span>Live</span></div>
          <div className="mt-5 space-y-3">
            {room.players.map((player) => <div key={player.id} className={`rounded-[15px] px-4 py-4 ${player.id === playerId ? "bg-[#d4f05b]" : "bg-[#f7f5ef]"}`}>
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-[12px] font-extrabold">{player.nickname}{player.id === playerId ? " · you" : ""}</span>
                {player.id === room.hostId && <span className="mono text-[8px] uppercase tracking-wider opacity-55">host</span>}
              </div>
              <div className="display mt-2 text-[34px] font-bold leading-none tracking-[-.07em]">{player.score}<span className="mono ml-2 text-[9px] font-normal uppercase tracking-[.14em]">pts</span></div>
            </div>)}
          </div>
          <div className="mt-5 border-t border-[#d7d4c9] pt-4 text-[11px] leading-5 text-[#718078]">
            {round ? "Next round is coming up automatically." : "Answer as fast as you can. The server keeps the score."}
          </div>
          {error && <p role="alert" className="mt-3 text-[11px] font-semibold text-[#a44e32]">{error}</p>}
        </aside>
      </div>
    </section>}

    {isFinished && room?.mode === "sprint" && room && <section className="mx-auto flex min-h-[calc(100dvh-76px)] max-w-[800px] flex-col justify-center px-5 py-12 sm:px-9">
      <div className="fade-up text-center">
        <div className="mono mb-5 text-[10px] uppercase tracking-[.18em] text-[#718078]">
          Sprint complete · {room.durationMinutes} {room.durationMinutes === 1 ? "minute" : "minutes"}
        </div>
        <div className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-[#d4f05b]">
          <svg viewBox="0 0 28 28" className="h-7 w-7" fill="none" aria-hidden="true"><path d="m7 14 4.5 4.5L21 9" stroke="#17211d" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <h1 className="display text-[clamp(3.1rem,8vw,5.5rem)] font-bold leading-[.92] tracking-[-.08em]">
          {room.winnerId === null ? "A perfect tie." : room.winnerId === playerId ? "You got it." : `${sprintWinner?.nickname ?? "Your friend"} wins.`}
          <span className="text-[#f2794b]">!</span>
        </h1>
        <p className="mt-4 text-[14px] text-[#718078]">
          {room.winnerId === null
            ? "The score and wrong-answer count are tied."
            : sprintWinner?.score === room.players.find((player) => player.id !== room.winnerId)?.score
              ? `${sprintWinner.nickname} wins the score tie with fewer wrong answers.`
              : "Highest score takes the Sprint."}
        </p>
      </div>
      <div className="fade-up-delay mx-auto mt-9 w-full max-w-[650px] rounded-[22px] border border-[#d7d4c9] bg-[#ebe8de] p-5 sm:p-7">
        <div className="mono mb-4 flex justify-between text-[10px] uppercase tracking-[.15em] text-[#718078]">
          <span>Final Sprint results</span>
          <span>{QUESTION_CATEGORY_LABELS[room.category] ?? "Maths"}</span>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {sprintResultPlayers.map((result) => <div key={result.id} className={`rounded-[16px] p-5 ${result.id === room.winnerId ? "bg-[#d4f05b]" : "bg-[#f7f5ef]"}`}>
            <div className="flex items-center justify-between gap-2">
              <span className="truncate text-[13px] font-extrabold">{result.nickname}{result.id === playerId ? " · you" : ""}</span>
              {result.id === room.winnerId && <span className="mono text-[8px] uppercase tracking-[.13em]">Winner</span>}
            </div>
            <div className="display mt-4 text-[42px] font-bold leading-none tracking-[-.08em]">{result.score}<span className="mono ml-2 text-[10px] font-medium uppercase tracking-[.15em]">points</span></div>
            <div className="mt-5 grid grid-cols-3 gap-2 border-t border-black/10 pt-4">
              <div><div className="mono text-[8px] uppercase tracking-[.1em] opacity-60">Correct</div><div className="mt-1 text-[14px] font-extrabold">{result.correctCount}</div></div>
              <div><div className="mono text-[8px] uppercase tracking-[.1em] opacity-60">Wrong</div><div className="mt-1 text-[14px] font-extrabold">{result.wrongCount}</div></div>
              <div><div className="mono text-[8px] uppercase tracking-[.1em] opacity-60">Accuracy</div><div className="mt-1 text-[14px] font-extrabold">{result.accuracy}%</div></div>
            </div>
          </div>)}
        </div>
        <div className="mt-5 flex flex-col items-center">
          <Button onClick={playAgain} disabled={!connected}>Play again <Arrow /></Button>
          <p className="mt-3 text-center text-[10px] text-[#718078]">Same room, another Sprint.</p>
        </div>
        {error && <p role="alert" className="mt-4 text-center text-[12px] font-semibold text-[#a44e32]">{error}</p>}
      </div>
    </section>}

    {isFinished && room?.mode !== "sprint" && room && <section className="mx-auto flex min-h-[calc(100dvh-76px)] max-w-[800px] flex-col justify-center px-5 py-12 sm:px-9">
      <div className="fade-up text-center">
        <div className="mono mb-5 text-[10px] uppercase tracking-[.18em] text-[#718078]">That’s the game · 5 rounds played</div>
        <div className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-[#d4f05b]">
          <svg viewBox="0 0 28 28" className="h-7 w-7" fill="none" aria-hidden="true"><path d="m7 14 4.5 4.5L21 9" stroke="#17211d" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <h1 className="display text-[clamp(3.1rem,8vw,5.5rem)] font-bold leading-[.92] tracking-[-.08em]">
          {room.winnerId === null ? "A perfect tie." : room.winnerId === playerId ? "You got it." : `${room.players.find((p) => p.id === room.winnerId)?.nickname ?? "Your friend"} wins.`}
          <span className="text-[#f2794b]">!</span>
        </h1>
        <p className="mt-4 text-[14px] text-[#718078]">{room.winnerId === null ? "Neither brain blinked first." : room.winnerId === playerId ? "The quick brain was yours today." : "They were just a little quicker this time."}</p>
      </div>
      <div className="fade-up-delay mx-auto mt-9 w-full max-w-[570px] rounded-[22px] border border-[#d7d4c9] bg-[#ebe8de] p-5 sm:p-7">
        <div className="mono mb-4 flex justify-between text-[10px] uppercase tracking-[.15em] text-[#718078]"><span>Final score</span><span>Room {room.roomCode}</span></div>
        <div className="grid gap-3 sm:grid-cols-2">
          {room.players.map((player) => <div key={player.id} className={`rounded-[16px] p-5 ${player.id === room.winnerId ? "bg-[#d4f05b]" : "bg-[#f7f5ef]"}`}>
            <div className="flex items-center justify-between gap-2">
              <span className="truncate text-[13px] font-extrabold">{player.nickname}{player.id === playerId ? " · you" : ""}</span>
              {player.id === room.winnerId && <span className="mono text-[8px] uppercase tracking-[.13em]">Winner</span>}
            </div>
            <div className="display mt-4 text-[48px] font-bold leading-none tracking-[-.08em]">{player.score}<span className="mono ml-2 text-[10px] font-medium uppercase tracking-[.15em]">points</span></div>
          </div>)}
        </div>
        <div className="mt-5 flex flex-col items-center">
          <Button onClick={playAgain} disabled={!connected}>Play again <Arrow /></Button>
          <p className="mt-3 text-center text-[10px] text-[#718078]">Same room, fresh five-round duel.</p>
        </div>
        {error && <p role="alert" className="mt-4 text-center text-[12px] font-semibold text-[#a44e32]">{error}</p>}
      </div>
    </section>}
    <footer className="mono fixed bottom-0 left-0 hidden w-full justify-between px-9 py-4 text-[9px] uppercase tracking-[.15em] text-[#9ba49b] md:flex">
      <span>Think fast, play nice</span><span>Escape Byte · Math, but make it a match</span>
    </footer>
  </main>;
}