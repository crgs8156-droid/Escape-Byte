import "./globals.css";

export const metadata = {
  title: "Escape Byte — a little brain duel",
  description: "A quick mental-math duel for you and a friend.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}