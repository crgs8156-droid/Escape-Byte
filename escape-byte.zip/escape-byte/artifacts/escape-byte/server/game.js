import { randomInt } from "node:crypto";
import {
  generateSprintSequence,
  SPRINT_ANSWER_COOLDOWN_MS,
} from "./generators.js";
import { QUESTION_BANK } from "./questions.js";

const ROOM_CODE_CHARACTERS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const QUESTION_COUNT = 5;
const QUESTION_TIME_MS = 10_000;
const ROUND_PAUSE_MS = 1_500;
const SPRINT_COUNTDOWN_MS = 3_000;
const SPRINT_FEEDBACK_MS = 350;
const SPRINT_DURATIONS_MINUTES = new Set([1, 2, 5]);
const ROOM_MODES = new Set(["classic", "sprint"]);
const ROOM_CATEGORIES = new Set([...Object.keys(QUESTION_BANK), "mixed"]);
const rooms = new Map();

function generateRoomCode() {
  let code = "";
  for (let index = 0; index < 4; index += 1) {
    code += ROOM_CODE_CHARACTERS[randomInt(ROOM_CODE_CHARACTERS.length)];
  }
  return code;
}

function makeRoomCode() {
  let code = generateRoomCode();
  while (rooms.has(code)) code = generateRoomCode();
  return code;
}

function cleanNickname(value) {
  if (typeof value !== "string") return null;
  const nickname = value.trim().replace(/\s+/g, " ").slice(0, 18);
  return nickname.length > 0 ? nickname : null;
}

function shuffle(values) {
  for (let index = values.length - 1; index > 0; index -= 1) {
    const swapIndex = randomInt(index + 1);
    [values[index], values[swapIndex]] = [values[swapIndex], values[index]];
  }
  return values;
}

function pickQuestions(category) {
  const categories = Object.keys(QUESTION_BANK);
  if (category !== "mixed") {
    return shuffle([...QUESTION_BANK[category]]).slice(0, QUESTION_COUNT);
  }

  const onePerCategory = categories.map((name) => {
    const questions = QUESTION_BANK[name];
    return questions[randomInt(questions.length)];
  });
  const selectedQuestions = new Set(onePerCategory);
  const remainingQuestions = categories.flatMap((name) =>
    QUESTION_BANK[name].filter((question) => !selectedQuestions.has(question)),
  );
  const additionalQuestions = shuffle(remainingQuestions).slice(
    0,
    QUESTION_COUNT - onePerCategory.length,
  );
  return shuffle([...onePerCategory, ...additionalQuestions]);
}

function publicQuestion(question, deadlineAt) {
  return {
    text: question.text,
    ...(question.options ? { options: [...question.options] } : {}),
    deadlineAt,
  };
}

function publicRoom(room) {
  const isSprint = room.mode === "sprint";
  return {
    roomCode: room.roomCode,
    hostId: room.hostId,
    mode: room.mode,
    durationMinutes: room.durationMinutes,
    category: room.category,
    phase: room.phase,
    players: room.players.map(({ id, nickname, score }) => {
      const stats = room.sprintStats?.get(id);
      return {
        id,
        nickname,
        score: isSprint ? stats?.score ?? 0 : score,
        ...(isSprint
          ? {
              questionsAnswered: stats?.answeredCount ?? 0,
              correctCount: stats?.correctCount ?? 0,
              wrongCount: stats?.wrongCount ?? 0,
            }
          : {}),
      };
    }),
    questionNumber: room.questionNumber,
    totalQuestions: isSprint ? null : QUESTION_COUNT,
    question: !isSprint && room.currentQuestion
      ? publicQuestion(room.currentQuestion, room.currentQuestion.deadlineAt)
      : null,
    lastRound: room.lastRound,
    winnerId: room.winnerId,
    sprint: isSprint && room.sprintStartAt
      ? {
          countdownEndsAt: room.sprintStartAt,
          endsAt: room.sprintEndsAt,
          serverNow: Date.now(),
        }
      : null,
    sprintResults: room.sprintResults,
  };
}

function sendRoomState(io, room) {
  io.to(room.roomCode).emit("room:state", publicRoom(room));
}

function clearRoomTimers(room) {
  if (room.timer) clearTimeout(room.timer);
  if (room.nextRoundTimer) clearTimeout(room.nextRoundTimer);
  room.timer = null;
  room.nextRoundTimer = null;
}

function sendNextQuestion(io, room) {
  if (room.phase !== "playing") return;
  const generated = room.questionDeck[room.questionNumber];
  if (!generated) {
    finishMatch(io, room);
    return;
  }
  room.questionNumber += 1;

  const deadlineAt = Date.now() + QUESTION_TIME_MS;
  room.currentQuestion = { ...generated, deadlineAt };
  room.lastRound = null;

  sendRoomState(io, room);
  io.to(room.roomCode).emit("game:question", {
    questionNumber: room.questionNumber,
    totalQuestions: QUESTION_COUNT,
    ...publicQuestion(generated, deadlineAt),
  });

  room.timer = setTimeout(() => finishRound(io, room, null), QUESTION_TIME_MS);
}

function finishMatch(io, room) {
  const [first, second] = room.players;
  room.phase = "finished";
  room.currentQuestion = null;
  room.winnerId =
    first.score === second.score
      ? null
      : first.score > second.score
        ? first.id
        : second.id;
  room.lastRound = null;
  sendRoomState(io, room);
}

function configuredSprintDuration(room) {
  const testDurationMs = Number(process.env.ESCAPE_BYTE_SPRINT_TEST_DURATION_MS);
  if (
    Number.isSafeInteger(testDurationMs) &&
    testDurationMs > 0 &&
    testDurationMs <= 5 * 60_000
  ) {
    return testDurationMs;
  }
  return room.durationMinutes * 60_000;
}

function sendSprintQuestion(io, room, playerId) {
  const progress = room.sprintStats?.get(playerId);
  if (!progress || room.phase !== "playing") return;
  const question = room.sprintSequence[progress.nextQuestionIndex];
  if (!question) return;

  const questionNumber = progress.nextQuestionIndex + 1;
  progress.nextQuestionIndex += 1;
  progress.currentQuestionNumber = questionNumber;
  progress.currentQuestion = question;

  io.to(playerId).emit("sprint:question", {
    questionNumber,
    category: question.category,
    text: question.text,
    ...(question.options ? { options: [...question.options] } : {}),
  });
}

function finishSprint(io, room) {
  if (room.mode !== "sprint" || room.phase !== "playing") return;
  clearRoomTimers(room);
  room.phase = "finished";
  room.currentQuestion = null;

  const [first, second] = room.players;
  const firstStats = room.sprintStats.get(first.id);
  const secondStats = room.sprintStats.get(second.id);
  if (firstStats.score !== secondStats.score) {
    room.winnerId = firstStats.score > secondStats.score ? first.id : second.id;
  } else if (firstStats.wrongCount !== secondStats.wrongCount) {
    room.winnerId = firstStats.wrongCount < secondStats.wrongCount ? first.id : second.id;
  } else {
    room.winnerId = null;
  }

  room.sprintResults = {
    players: room.players.map(({ id, nickname }) => {
      const stats = room.sprintStats.get(id);
      return {
        id,
        nickname,
        score: stats.score,
        questionsAnswered: stats.answeredCount,
        correctCount: stats.correctCount,
        wrongCount: stats.wrongCount,
        accuracy:
          stats.answeredCount > 0
            ? Math.round((stats.correctCount / stats.answeredCount) * 1000) / 10
            : 0,
      };
    }),
  };
  sendRoomState(io, room);
}

function finishRound(io, room, winnerId) {
  if (room.phase !== "playing" || !room.currentQuestion) return;

  if (room.timer) clearTimeout(room.timer);
  room.timer = null;
  const questionNumber = room.questionNumber;

  if (winnerId) {
    const winner = room.players.find((player) => player.id === winnerId);
    if (winner) winner.score += 1;
  }

  room.lastRound = { winnerId };
  room.currentQuestion = null;

  io.to(room.roomCode).emit("game:round-result", {
    winnerId,
    questionNumber,
    scores: Object.fromEntries(room.players.map((player) => [player.id, player.score])),
  });
  sendRoomState(io, room);

  if (questionNumber === QUESTION_COUNT) {
    room.nextRoundTimer = setTimeout(() => finishMatch(io, room), ROUND_PAUSE_MS);
    return;
  }

  room.nextRoundTimer = setTimeout(
    () => sendNextQuestion(io, room),
    ROUND_PAUSE_MS,
  );
}

function startSprint(io, room) {
  if (room.phase !== "countdown") return;
  room.phase = "playing";
  sendRoomState(io, room);
  for (const player of room.players) sendSprintQuestion(io, room, player.id);
  room.timer = setTimeout(
    () => finishSprint(io, room),
    Math.max(0, room.sprintEndsAt - Date.now()),
  );
}

function startSprintCountdown(io, room) {
  clearRoomTimers(room);
  room.phase = "countdown";
  room.questionNumber = 0;
  room.currentQuestion = null;
  room.lastRound = null;
  room.winnerId = null;
  room.sprintResults = null;
  room.sprintDurationMs = configuredSprintDuration(room);
  room.sprintStartAt = Date.now() + SPRINT_COUNTDOWN_MS;
  room.sprintEndsAt = room.sprintStartAt + room.sprintDurationMs;
  room.sprintSequence = generateSprintSequence(
    room.category,
    room.sprintDurationMs,
  );
  room.sprintStats = new Map(
    room.players.map((player) => [
      player.id,
      {
        score: 0,
        answeredCount: 0,
        correctCount: 0,
        wrongCount: 0,
        nextQuestionIndex: 0,
        currentQuestionNumber: null,
        currentQuestion: null,
        lastAnswerAt: null,
      },
    ]),
  );
  for (const player of room.players) player.score = 0;
  sendRoomState(io, room);
  room.timer = setTimeout(
    () => startSprint(io, room),
    Math.max(0, room.sprintStartAt - Date.now()),
  );
}

function startClassicGame(io, room) {
  clearRoomTimers(room);
  room.phase = "playing";
  room.questionNumber = 0;
  room.currentQuestion = null;
  room.questionDeck = pickQuestions(room.category);
  room.lastRound = null;
  room.winnerId = null;
  for (const player of room.players) player.score = 0;
  sendNextQuestion(io, room);
}

function startGame(io, room) {
  if (room.mode === "sprint") {
    startSprintCountdown(io, room);
    return;
  }
  startClassicGame(io, room);
}

function leaveCurrentRoom(io, socket) {
  const { roomCode, playerId } = socket.data;
  if (!roomCode || !playerId) return;

  const room = rooms.get(roomCode);
  socket.data.roomCode = undefined;
  socket.data.playerId = undefined;
  if (!room) return;

  room.players = room.players.filter((player) => player.id !== playerId);
  socket.leave(roomCode);

  if (room.players.length === 0) {
    clearRoomTimers(room);
    rooms.delete(roomCode);
    return;
  }

  clearRoomTimers(room);
  room.hostId = room.players[0].id;
  room.phase = "lobby";
  room.questionNumber = 0;
  room.currentQuestion = null;
  room.lastRound = null;
  room.winnerId = null;
  room.sprintDurationMs = null;
  room.sprintStartAt = null;
  room.sprintEndsAt = null;
  room.sprintSequence = null;
  room.sprintStats = null;
  room.sprintResults = null;
  sendRoomState(io, room);
}

function parseAnswer(question, answer) {
  if (Array.isArray(question.options)) {
    const parsedIndex =
      typeof answer === "number"
        ? answer
        : typeof answer === "string" && /^\d+$/.test(answer.trim())
          ? Number(answer.trim())
          : Number.NaN;
    return (
      Number.isInteger(parsedIndex) &&
      parsedIndex >= 0 &&
      parsedIndex < question.options.length &&
      parsedIndex === question.answerIndex
    );
  }
  const parsedValue =
    typeof answer === "string" && /^-?\d+$/.test(answer.trim())
      ? Number(answer.trim())
      : Number.NaN;
  return parsedValue === question.answer;
}

function handleSprintAnswer(io, room, socket, { answer, questionNumber }) {
  if (!room || room.mode !== "sprint" || room.phase !== "playing") return;
  if (Date.now() >= room.sprintEndsAt) {
    finishSprint(io, room);
    return;
  }

  const progress = room.sprintStats.get(socket.data.playerId);
  if (
    !progress ||
    progress.currentQuestionNumber === null ||
    questionNumber !== progress.currentQuestionNumber
  ) {
    return;
  }

  const now = Date.now();
  if (
    progress.lastAnswerAt !== null &&
    now - progress.lastAnswerAt < SPRINT_ANSWER_COOLDOWN_MS
  ) {
    return;
  }
  progress.lastAnswerAt = now;

  const correct = parseAnswer(progress.currentQuestion, answer);
  progress.answeredCount += 1;
  if (correct) {
    progress.correctCount += 1;
    progress.score += 1;
  } else {
    progress.wrongCount += 1;
    progress.score = Math.max(0, progress.score - 1);
  }
  progress.currentQuestion = null;
  progress.currentQuestionNumber = null;

  socket.emit("sprint:answer-result", {
    correct,
    feedbackMs: SPRINT_FEEDBACK_MS,
    score: progress.score,
  });
  sendRoomState(io, room);
  sendSprintQuestion(io, room, socket.data.playerId);
}

export function registerGameHandlers(io) {
  io.on("connection", (socket) => {
    socket.on("room:create", ({ nickname, category, mode, durationMinutes }, acknowledge) => {
      const safeName = cleanNickname(nickname);
      if (!safeName) {
        acknowledge({ ok: false, error: "Enter a nickname to continue." });
        return;
      }
      const safeMode =
        typeof mode === "string" ? mode.trim().toLowerCase() : "classic";
      if (!ROOM_MODES.has(safeMode)) {
        acknowledge({ ok: false, error: "Choose Classic or Sprint mode." });
        return;
      }
      const safeDuration = Number(durationMinutes);
      if (
        safeMode === "sprint" &&
        !SPRINT_DURATIONS_MINUTES.has(safeDuration)
      ) {
        acknowledge({
          ok: false,
          error: "Choose a Sprint duration of 1, 2, or 5 minutes.",
        });
        return;
      }
      const safeCategory =
        typeof category === "string" ? category.trim().toLowerCase() : "";
      if (!ROOM_CATEGORIES.has(safeCategory)) {
        acknowledge({ ok: false, error: "Choose a valid question category." });
        return;
      }

      leaveCurrentRoom(io, socket);
      const roomCode = makeRoomCode();
      const playerId = socket.id;
      const room = {
        roomCode,
        hostId: playerId,
        mode: safeMode,
        durationMinutes: safeMode === "sprint" ? safeDuration : null,
        category: safeCategory,
        phase: "lobby",
        players: [{ id: playerId, nickname: safeName, score: 0 }],
        questionNumber: 0,
        currentQuestion: null,
        questionDeck: [],
        lastRound: null,
        winnerId: null,
        sprintDurationMs: null,
        sprintStartAt: null,
        sprintEndsAt: null,
        sprintSequence: null,
        sprintStats: null,
        sprintResults: null,
        timer: null,
        nextRoundTimer: null,
      };

      rooms.set(roomCode, room);
      socket.data.roomCode = roomCode;
      socket.data.playerId = playerId;
      socket.join(roomCode);
      acknowledge({ ok: true, roomCode, playerId });
      sendRoomState(io, room);
    });

    socket.on("room:join", ({ nickname, roomCode }, acknowledge) => {
      const safeName = cleanNickname(nickname);
      const safeCode =
        typeof roomCode === "string" ? roomCode.trim().toUpperCase() : "";
      if (!safeName) {
        acknowledge({ ok: false, error: "Enter a nickname to continue." });
        return;
      }
      if (!/^[A-Z0-9]{4}$/.test(safeCode)) {
        acknowledge({ ok: false, error: "Room codes have four characters." });
        return;
      }

      const room = rooms.get(safeCode);
      if (!room) {
        acknowledge({ ok: false, error: "That room could not be found." });
        return;
      }
      if (room.phase !== "lobby" || room.players.length >= 2) {
        acknowledge({ ok: false, error: "That room is already full." });
        return;
      }

      leaveCurrentRoom(io, socket);
      const playerId = socket.id;
      room.players.push({ id: playerId, nickname: safeName, score: 0 });
      socket.data.roomCode = safeCode;
      socket.data.playerId = playerId;
      socket.join(safeCode);
      acknowledge({ ok: true, roomCode: safeCode, playerId });
      sendRoomState(io, room);
    });

    socket.on("room:start", () => {
      const room = socket.data.roomCode
        ? rooms.get(socket.data.roomCode)
        : undefined;
      if (!room || socket.data.playerId !== room.hostId) {
        socket.emit("room:error", { message: "Only the host can start the duel." });
        return;
      }
      if (room.phase !== "lobby" || room.players.length !== 2) {
        socket.emit("room:error", { message: "Wait for two players before starting." });
        return;
      }
      startGame(io, room);
    });

    socket.on("game:answer", ({ answer }) => {
      const room = socket.data.roomCode
        ? rooms.get(socket.data.roomCode)
        : undefined;
      if (room?.mode === "sprint") return;
      const question = room?.currentQuestion;
      if (!room || room.phase !== "playing" || !question) return;

      if (Date.now() > question.deadlineAt) {
        finishRound(io, room, null);
        return;
      }

      if (!parseAnswer(question, answer)) {
        socket.emit("game:answer-feedback", { correct: false });
        return;
      }

      socket.emit("game:answer-feedback", { correct: true });
      finishRound(io, room, socket.data.playerId ?? null);
    });

    socket.on("sprint:answer", (payload = {}) => {
      const room = socket.data.roomCode
        ? rooms.get(socket.data.roomCode)
        : undefined;
      handleSprintAnswer(io, room, socket, payload);
    });

    socket.on("room:play-again", () => {
      const room = socket.data.roomCode
        ? rooms.get(socket.data.roomCode)
        : undefined;
      if (!room || room.phase !== "finished" || room.players.length !== 2) {
        socket.emit("room:error", {
          message: "A rematch is available after a completed duel.",
        });
        return;
      }
      startGame(io, room);
    });

    socket.on("disconnect", () => leaveCurrentRoom(io, socket));
  });
}