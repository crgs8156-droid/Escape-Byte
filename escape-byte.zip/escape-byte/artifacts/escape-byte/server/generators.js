import { randomInt } from "node:crypto";
import { QUESTION_BANK } from "./questions.js";

export const SPRINT_ANSWER_COOLDOWN_MS = 300;

function shuffle(values) {
  for (let index = values.length - 1; index > 0; index -= 1) {
    const swapIndex = randomInt(index + 1);
    [values[index], values[swapIndex]] = [values[swapIndex], values[index]];
  }
  return values;
}

function questionCountFor(durationMs) {
  return Math.ceil(durationMs / SPRINT_ANSWER_COOLDOWN_MS) + 1;
}

function shuffledBankQuestion(question) {
  const correctOption = question.options[question.answerIndex];
  const options = shuffle([...question.options]);
  return {
    category: "code",
    text: question.text,
    options,
    answerIndex: options.indexOf(correctOption),
  };
}

function createCodeSequence(count) {
  const sequence = [];
  let pool = [];
  let lastText = null;

  while (sequence.length < count) {
    if (pool.length === 0) {
      pool = shuffle([...QUESTION_BANK.code]);
      if (pool.length > 1 && pool[0].text === lastText) {
        const otherIndex = pool.findIndex((question, index) =>
          index > 0 && question.text !== lastText,
        );
        [pool[0], pool[otherIndex]] = [pool[otherIndex], pool[0]];
      }
    }

    const nextQuestion = pool.shift();
    sequence.push(shuffledBankQuestion(nextQuestion));
    lastText = nextQuestion.text;
  }

  return sequence;
}

function createLogicQuestion() {
  const isGeometric = randomInt(2) === 1;
  const start = isGeometric ? randomInt(1, 6) : randomInt(1, 13);
  const step = isGeometric ? randomInt(2, 4) : randomInt(2, 10);
  const terms = Array.from({ length: 5 }, (_, index) =>
    isGeometric ? start * step ** index : start + step * index,
  );
  const answer = isGeometric ? terms[4] * step : terms[4] + step;
  const distractors = isGeometric
    ? [answer / step, answer + step, answer * 2]
    : [answer - step, answer + step, answer + step * 2];
  const options = shuffle([...new Set([answer, ...distractors])]);

  return {
    category: "logic",
    text: `Complete the pattern:\n${terms.join(", ")}, ?`,
    options: options.map(String),
    answerIndex: options.indexOf(answer),
  };
}

function createLogicSequence(count) {
  const sequence = [];
  let existingPool = [];
  let lastExistingText = null;

  for (let index = 0; index < count; index += 1) {
    if (index % 2 === 0) {
      sequence.push(createLogicQuestion());
      continue;
    }

    if (existingPool.length === 0) {
      existingPool = shuffle([...QUESTION_BANK.logic]);
      if (existingPool.length > 1 && existingPool[0].text === lastExistingText) {
        const otherIndex = existingPool.findIndex((question, poolIndex) =>
          poolIndex > 0 && question.text !== lastExistingText,
        );
        [existingPool[0], existingPool[otherIndex]] = [
          existingPool[otherIndex],
          existingPool[0],
        ];
      }
    }

    const question = existingPool.shift();
    sequence.push({
      category: "logic",
      text: question.text,
      options: [...question.options],
      answerIndex: question.answerIndex,
    });
    lastExistingText = question.text;
  }

  return sequence;
}

function createMathQuestion(progressIndex, totalMathQuestions) {
  const progress = progressIndex / Math.max(1, totalMathQuestions);

  if (progress >= 2 / 3) {
    const left = randomInt(2, 13);
    const right = randomInt(2, 13);
    return {
      category: "maths",
      text: `${left} × ${right}`,
      answer: left * right,
    };
  }

  if (progress >= 1 / 3) {
    const left = randomInt(20, 100);
    const right = randomInt(10, 80);
    if (randomInt(2) === 0) {
      return {
        category: "maths",
        text: `${left} + ${right}`,
        answer: left + right,
      };
    }
    const larger = Math.max(left, right);
    const smaller = Math.min(left, right);
    return {
      category: "maths",
      text: `${larger} − ${smaller}`,
      answer: larger - smaller,
    };
  }

  const left = randomInt(1, 11);
  const right = randomInt(1, 11);
  if (randomInt(2) === 0) {
    return {
      category: "maths",
      text: `${left} + ${right}`,
      answer: left + right,
    };
  }
  const larger = Math.max(left, right);
  const smaller = Math.min(left, right);
  return {
    category: "maths",
    text: `${larger} − ${smaller}`,
    answer: larger - smaller,
  };
}

export function generateSprintSequence(category, durationMs) {
  if (!["maths", "code", "logic", "mixed"].includes(category)) {
    throw new Error("A valid Sprint category is required.");
  }
  if (!Number.isSafeInteger(durationMs) || durationMs <= 0) {
    throw new Error("Sprint duration must be a positive number of milliseconds.");
  }

  const totalQuestions = questionCountFor(durationMs);
  const sequenceCategories =
    category === "mixed"
      ? Array.from({ length: totalQuestions }, (_, index) =>
          ["maths", "logic", "code"][index % 3],
        )
      : Array(totalQuestions).fill(category);
  const counts = Object.fromEntries(
    ["maths", "logic", "code"].map((name) => [
      name,
      sequenceCategories.filter((entry) => entry === name).length,
    ]),
  );
  const sequences = {
    maths: Array.from({ length: counts.maths }, (_, index) =>
      createMathQuestion(index, counts.maths),
    ),
    logic: createLogicSequence(counts.logic),
    code: createCodeSequence(counts.code),
  };
  const positions = { maths: 0, logic: 0, code: 0 };

  return sequenceCategories.map((name) => {
    const question = sequences[name][positions[name]];
    positions[name] += 1;
    return question;
  });
}