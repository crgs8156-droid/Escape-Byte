import express from "express";
import { createServer } from "node:http";
import { join } from "node:path";
import next from "next";
import { Server } from "socket.io";
import { registerGameHandlers } from "./game.js";

const port = Number(process.env.PORT ?? 3000);
if (!Number.isInteger(port) || port <= 0) {
  throw new Error(`Invalid PORT value: ${process.env.PORT}`);
}

const clientDirectory = join(process.cwd(), "client");
const isDevelopment = process.env.NODE_ENV !== "production";
const nextApp = next({ dev: isDevelopment, dir: clientDirectory });

await nextApp.prepare();

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { path: "/socket.io" });
const handleNextRequest = nextApp.getRequestHandler();

registerGameHandlers(io);

app.get("/healthz", (_request, response) => {
  response.json({ status: "ok" });
});
app.use((request, response) => handleNextRequest(request, response));

httpServer.listen(port, "0.0.0.0", () => {
  process.stdout.write(`Escape Byte is listening on port ${port}\n`);
});